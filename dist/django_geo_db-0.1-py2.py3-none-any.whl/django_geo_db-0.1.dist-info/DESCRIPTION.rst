# django-geo-db

A library that creates a geo empowered app in Django. This library contains both models and data for making geo in the US, straight forward.


